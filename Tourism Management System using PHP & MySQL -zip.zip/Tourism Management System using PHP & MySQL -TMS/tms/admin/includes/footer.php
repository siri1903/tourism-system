<div class="copyrights">
	 <p>© 2023 TMS. All Rights Reserved |  <a href="#">TMS</a> </p>
</div>	
